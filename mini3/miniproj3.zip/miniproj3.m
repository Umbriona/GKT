%% Uppgift 1
clf
clc
f=1;
xf=0.2222; % xf anger molbr�ket f�r komponent A
Pt=760; %tryck i torr
I=1;    % I=1 om systemet �r idealt I=2 om systemet �r icke idealt
s=1;    % s anger vilket system vi tittar p� 1-5


miniprojekt3(f,xf,Pt,s,I)

%% Uppgift 2
clc
clf

f=2;
xf=0.5; % xf anger molbr�ket f�r komponent A
Pt=760; %tryck i torr
I=2;    % I=1 om systemet �r idealt I=2 om systemet �r icke idealt
s=2;    % s anger vilket system vi tittar p� 1-5


miniprojekt3(f,xf,Pt,s,I)

%% Uppgift 3
clf
clc

f=3;
xf=0.5; % xf anger molbr�ket f�r komponent A
Pt=760; %tryck i torr
I=2;    % I=1 om systemet �r idealt I=2 om systemet �r icke idealt
s=2;    % s anger vilket system vi tittar p� 1-5


miniprojekt3(f,xf,Pt,s,I)

%% Uppgift 4
clc
clf


f=4;
xf=0.5; % xf �r i denna uppgift oviktig 
Pt=760*4; %tryck i torr
I=2;    % I=1 om systemet �r idealt I=2 om systemet �r icke idealt
s=4;    % s anger vilket system vi tittar p� 1-5


miniprojekt3(f,xf,Pt,s,I)

%% Uppgift 5
clc
clf


f=5;
xf=0.5; % xf �r i denna uppgift oviktig
Pt=760*4; %tryck i torr
I=1;    % I=1 om systemet �r idealt I=2 om systemet �r icke idealt
s=4;    % s anger vilket system vi tittar p� 1-5


miniprojekt3(f,xf,Pt,s,I)

%% Uppgift 6
clf
clc

f=6;
xf=0.5; % xf anger molbr�ket f�r komponent A
Pt=760*4; %tryck i torr
I=2;    % I=1 om systemet �r idealt I=2 om systemet �r icke idealt
s=4;    % s anger vilket system vi tittar p� 1-5


miniprojekt3(f,xf,Pt,s,I)




