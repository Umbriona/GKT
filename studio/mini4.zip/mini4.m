%% Uppgift 1 

U=1; % v�lj vilket fall du vill titta p� (1-60)
miniprojekt4(U)

%%
